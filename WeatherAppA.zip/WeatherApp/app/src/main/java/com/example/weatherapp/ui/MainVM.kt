package com.example.weatherapp.ui

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.weatherapp.core.model.current.CurrentWeatherResponse
import com.example.weatherapp.core.repository.WeatherRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainVM @Inject constructor(private val repository: WeatherRepository) : ViewModel() {

    val weatherLiveData: MutableLiveData<CurrentWeatherResponse?> = MutableLiveData()
    val errorLiveData: MutableLiveData<String?> = MutableLiveData()

     fun getWeatherInformation() {

        viewModelScope.launch {
            val result = repository.getWeatherData("")
            result.data.let {
                weatherLiveData.value = it
            }
        }

    }

}