package com.example.weatherapp.core.util

 object Utils {
     const val API_KEY = "12ebfcde12d5420cbde73125232812"
}