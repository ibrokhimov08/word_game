package com.example.weatherapp.core.repository

import com.example.weatherapp.core.model.current.CurrentWeatherResponse
import com.example.weatherapp.core.network.service.WeatherService
import com.example.weatherapp.core.util.ResultWrapper
import javax.inject.Inject


class WeatherRepository @Inject constructor(private val service: WeatherService) {


    suspend fun getWeatherData(): ResultWrapper<CurrentWeatherResponse?, Any?> {



    }


}