package com.uz.Ibrokhimov.exam_project.core.util

val API_KEY = "10137bab07a7a987b23a902a78d6986c"