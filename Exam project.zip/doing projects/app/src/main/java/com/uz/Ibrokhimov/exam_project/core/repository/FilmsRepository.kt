package com.uz.Ibrokhimov.exam_project.core.repository

import com.uz.Ibrokhimov.exam_project.core.network.ApiClient
import com.uz.Ibrokhimov.exam_project.core.util.API_KEY
import com.uz.Ibrokhimov.exam_project.core.util.ResultWrapper

class FilmsRepository {

    val service = ApiClient.getFilmsNowPlaying()

    suspend fun getFilms(): ResultWrapper<FilmsResponse> {

        val response = service.getNowPlaying(API_KEY)

        if (response.isSuccessful){
            response.body()?.let { return ResultWrapper(it) }
        }

        return ResultWrapper(error = "Error")
    }

}