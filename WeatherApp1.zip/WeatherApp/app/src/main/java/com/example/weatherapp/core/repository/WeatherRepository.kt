package com.example.weatherapp.core.repository

import com.example.weatherapp.core.model.current.CurrentWeatherResponse
import com.example.weatherapp.core.network.service.WeatherService
import com.example.weatherapp.core.util.ResultWrapper
import com.example.weatherapp.core.util.Utils.API_KEY
import javax.inject.Inject


class WeatherRepository @Inject constructor(val service: WeatherService) {


    suspend fun getWeatherData(): ResultWrapper<CurrentWeatherResponse?, Any?> {
        val data = service.loadCurrentWeather(API_KEY, "Tashkent")
        return ResultWrapper.Success(code = data.code(), response = data.body())
    }


}