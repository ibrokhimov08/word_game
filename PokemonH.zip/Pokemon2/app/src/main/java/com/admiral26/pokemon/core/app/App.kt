package com.admiral26.pokemon.core.app

import android.app.Application
import com.admiral26.pokemon.core.data.PokemonDt


class App : Application() {

    override fun onCreate() {
        super.onCreate()
      PokemonDt.loadData()

    }

}