package com.admiral26.pokemon.core.base

import android.app.Application

class BaseActivity :Application() {





}