package com.admiral26.pokemon.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.admiral26.pokemon.core.adapter.PokemonAdapter
import com.admiral26.pokemon.core.data.PokemonDt
import com.admiral26.pokemon.databinding.ActivityMainBinding



class MainActivity : AppCompatActivity() {
    private val binding by lazy { ActivityMainBinding.inflate(layoutInflater) }
    private val adapter = PokemonAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        setAdapter()
        loadAction()
    }

    private fun setAdapter() {
        binding.pokemonList.adapter = adapter
        binding.pokemonList.layoutManager = GridLayoutManager(this, 2)
        adapter.setData(PokemonDt.getPokemon())
    }

    private fun loadAction() {
        adapter.setOnclickView = {
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra("POKEMON",it)
            
            startActivity(intent)
        }
    }
}