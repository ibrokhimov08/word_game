package com.admiral26.pokemon.ui

import android.content.Intent
import android.graphics.drawable.Drawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.admiral26.pokemon.R
import com.admiral26.pokemon.core.model.PokemonModel
import com.admiral26.pokemon.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {

    private val binding by lazy { ActivityDetailBinding.inflate(layoutInflater) }
    private val pokemon = intent.getSerializableExtra("POKEMON")
    private val data = pokemon as PokemonModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        setMax()
        loadView()

    }

    private fun setMax() {
        binding.progressOfHp.max = 10
        binding.progressDefence.max = 10
        binding.progressOfAttact.max = 10
        binding.progressSpeed.max = 10
    }

    private fun loadView() {

        binding.progressOfHp.progress = data.hp
        binding.progressDefence.progress = data.defence
        binding.progressOfAttact.progress = data.attack
        binding.progressSpeed.progress = data.speed

        binding.height.text = data.height.toString()
        binding.image.setImageDrawable(getDrawable(data.image))
        binding.weight.text = data.weight.toString()
    }


}