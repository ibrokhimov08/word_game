package com.example.weatherapp.ui

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.weatherapp.core.model.current.CurrentWeatherResponse
import com.example.weatherapp.core.repository.WeatherRepository
import kotlinx.coroutines.launch

class MainVM() : ViewModel() {

    private val repository = WeatherRepository()
    val weatherLiveData: MutableLiveData<CurrentWeatherResponse?> = MutableLiveData()
    val errorLiveData: MutableLiveData<String?> = MutableLiveData()

    suspend fun getWeatherInformation() {

        viewModelScope.launch {
            val result = repository.getWeatherData()
            result.data.let {
                weatherLiveData.value = it
            }
        }

    }

}