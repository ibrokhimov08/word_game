package com.example.weatherapp.core.repository

import com.example.weatherapp.core.model.current.CurrentWeatherResponse
import com.example.weatherapp.core.util.Utils.API_KEY
import com.example.weatherapp.core.network.ApiClient
import com.example.weatherapp.core.util.ResultWrapper


class WeatherRepository {

    private val service = ApiClient.createWeatherService()


    suspend fun getWeatherData(): ResultWrapper<CurrentWeatherResponse> {
        val response = service.loadCurrentWeather(API_KEY, "Tashkent")

        if (response.isSuccessful) {
            response.body()?.let { return ResultWrapper(it) }
        }
        return ResultWrapper(error = "Error")
    }

}