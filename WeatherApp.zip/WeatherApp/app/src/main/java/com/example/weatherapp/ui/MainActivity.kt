package com.example.weatherapp.ui

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.core.view.isGone
import by.kirich1409.viewbindingdelegate.viewBinding
import coil.load
import com.example.weatherapp.R
import com.example.weatherapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private val binding by viewBinding(ActivityMainBinding::bind)
    private val mainVM: MainVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)


    }



    /*private fun sendRequest(region: String) {
        val service = ApiClient.createWeatherService()
        service.loadCurrentWeather(API_KEY, region)
            .enqueue(object : Callback<CarrentWeatherResponse> {
                override fun onResponse(
                    call: Call<CarrentWeatherResponse>,
                    response: Response<CarrentWeatherResponse>
                ) {
                    if (response.isSuccessful) {
                        val data = response.body()!!
                        binding.textView.text = "${data.current.tempC}\n${data.location.region}"
                        binding.progressBar.isVisible = false
                    } else {
                        binding.progressBar.isVisible = false
                        binding.textView.text = "Clent Eror"
                    }
                }

                override fun onFailure(call: Call<CarrentWeatherResponse>, t: Throwable) {
                    binding.progressBar.isVisible = false
                    binding.textView.text = "Fatal"
                }
            })
    }*/
}