package com.example.weatherapp.ui

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.core.view.isGone
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import by.kirich1409.viewbindingdelegate.viewBinding
import coil.load
import com.example.weatherapp.R
import com.example.weatherapp.databinding.ActivityMainBinding
import com.example.weatherapp.databinding.ScreenMainBinding

class MainScreen : Fragment(R.layout.screen_main){

    private val binding by viewBinding(ScreenMainBinding::bind)
    private val mainVM: MainVM by viewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadView()

    }


    private fun loadView() {

        mainVM.weatherLiveData.observe(viewLifecycleOwner) {

            it.let {
                binding.icon.load(it!!.current.condition.icon)
                binding.degree.text = "${it.current.tempC}"
                binding.hl.text = "H:${it.current.feelslikeC}°  L:${it.current.tempF}°"
                binding.function.text = it.current.condition.text
                binding.progressBar.isGone = true
            }

        }

    }



    /*
    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        var reregion = "Andijon"
        when (item.itemId) {

            R.id.Andijon -> {
                reregion = "Andijon"

            }

            R.id.Namangan -> {
                reregion = "Namangan"
            }

            R.id.Qarshi -> {
                reregion = "Qarshi"

            }

            R.id.Jizzah -> {
                reregion = "Jizzah"

            }

            R.id.Tashkent -> {
                reregion = "Tashkent"
            }
        }
        return true
    }*/

}